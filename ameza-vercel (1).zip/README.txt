VERCEL DEPLOY (2 tareeqe)

A) CLI (sabse aasaan)
   1. Node.js install hona chahiye
   2. Is folder mein terminal kholein
   3. npx vercel --prod
   4. Login karein, sab sawalon par Enter dabayein -> aap ko live link mil jayega

B) GitHub se
   1. In 2 files ko naye GitHub repo mein upload karein
   2. vercel.com/new > repo import > Framework: Other > Deploy

Note: Ye sirf demo/landing page hai. Cart aur checkout ke liye Shopify theme (ameza-store.zip) use karein.
